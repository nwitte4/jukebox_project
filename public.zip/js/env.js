const ENV = (function () {
  const client_id = 'fd4e76fc67798bfa742089ed619084a6';

  return { client_id }
})();
