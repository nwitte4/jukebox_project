const Counter = class Counter {
  constructor(max, value){
    this.max = max;
    this.value = 0;
  }
  up(){
    this.value + 1 !== this.max ? this.value += 1 : this.value;
    return this;
  }
  down(){
    this.value - 1 >= 0 ? this.value -= 1 : this.value;
    return this;
  }
}
var track; var trackList;
let i = 0;
var playButton = document.getElementById('play-button');
var pauseButton = document.getElementById('pause-button');
var nextButton = document.getElementById('next-button');
var stopButton = document.getElementById('stop-button')
var titleBox = document.getElementById('title');
var descriptionBox = document.getElementById('description');
var genreBox = document.getElementById('genre');
var releaseDateBox = document.getElementById('releaseDate');
var artworkBox = document.getElementById('artwork');

(function(ENV) {
  const client_id = ENV.client_id;


  SC.initialize({
    client_id: client_id
  });
  // stream track id 293
  // SC.stream('/tracks/124296667').then(function(player) {
  // });
  // find all sounds of buskers licensed under 'creative commons share alike'
  SC.get('/tracks', {
    q: 'chance the rapper',
  }).then(function(tracks) {
    trackList = tracks;
    var counter = new Counter(tracks.length)
    let currentTrack = tracks[counter.value];

      SC.stream('/tracks/' + currentTrack.id).then(function(player){

      let title = currentTrack.title || '¯\\_(ツ)_/¯'
      let description = currentTrack.description || '¯\\_(ツ)_/¯'
      let genre = currentTrack.genre || '¯\\_(ツ)_/¯'
      let releaseDate = currentTrack.release_year || "¯\\_(ツ)_/¯"
      let artwork = currentTrack.artwork_url || '¯\\_(ツ)_/¯'
      let titleLink = currentTrack.permalink_url || '¯\\_(ツ)_/¯'

      function playSong(player){
        player.play();
      }
      function pauseSong(player){
        player.pause();
      }
      function stopSong(player){
        player.pause();
        player.seek(0);
      }
      function nextSong(event){
        //tracks[counter.up().value]
        tracks[counter.up()];
        let currentTrack = tracks[counter.value];
        SC.stream('/tracks/' + currentTrack.id).then(function(player){
          player.play();
          let title = currentTrack.title || '¯\\_(ツ)_/¯'
          let description = currentTrack.description || '¯\\_(ツ)_/¯'
          let genre = currentTrack.genre || '¯\\_(ツ)_/¯'
          let releaseDate = currentTrack.release_year || "¯\\_(ツ)_/¯"
          let artwork = currentTrack.artwork_url || '¯\\_(ツ)_/¯'
          let titleLink = currentTrack.permalink_url || '¯\\_(ツ)_/¯'

          playButton.addEventListener('click', function(event){
            playSong(player)
          });
          pauseButton.addEventListener('click', function(event){
            pauseSong(player)
          });
          nextButton.addEventListener('click', function(event){
            nextSong(player)
          });
          stopButton.addEventListener('click', function(event){
            stopSong(player)
          });
          titleBox.innerText = 'TITLE: ' + title;
          titleBox.setAttribute("href", titleLink);
          descriptionBox.innerText = 'DESCRIPTION: ' + description;
          genreBox.innerText = 'GENRE: ' + genre;
          releaseDateBox.innerText = 'RELEASE DATE: ' + releaseDate;
          artworkBox.src = artwork;
        });
      }

      titleBox.innerText = 'TITLE: ' + title;
      titleBox.setAttribute("href", titleLink);
      descriptionBox.innerText = 'DESCRIPTION: ' + description;
      genreBox.innerText = 'GENRE: ' + genre;
      releaseDateBox.innerText = 'RELEASE DATE: ' + releaseDate;
      artworkBox.src = artwork;

      playButton.addEventListener('click', function(event){
        playSong(player)
      });
      pauseButton.addEventListener('click', function(event){
        pauseSong(player)
      });
      nextButton.addEventListener('click', function(event){
        nextSong(player)
      });
      stopButton.addEventListener('click', function(event){
        stopSong(player)
      });

      // playButton.addEventListener('click', playSong)
      // pauseButton.addEventListener('click',pauseSong)
      // nextButton.addEventListener('click', nextSong)
      // stopButton.addEventListener('click', stopSong)
      });

  });

})(ENV);
